"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// src/core/winHideChildProcessLogic.js
var require_winHideChildProcessLogic = __commonJS({
  "src/core/winHideChildProcessLogic.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var CONSOLE_EXECUTABLES = /^(cmd|powershell|pwsh|wmic|tasklist|reg|findstr|where|whoami|systeminfo|netstat|sc|net|chcp|hostname|conhost)(\.exe)?$/i;
    var BROWSER_EXECUTABLES = /^(sunbrowser|flowerbrowser|chrome|chromium|msedge|firefox|brave|opera)(\.exe)?$/i;
    function getExecutableBaseName(command) {
      const trimmed = String(command).trim();
      let executable = trimmed;
      const quotedMatch = trimmed.match(/^"([^"]+)"|^'([^']+)'/);
      if (quotedMatch) {
        executable = quotedMatch[1] || quotedMatch[2];
      } else {
        executable = trimmed.split(/\s+/)[0] || trimmed;
      }
      executable = executable.replace(/^["']|["']$/g, "");
      return path.basename(executable.replace(/\\/g, "/")).toLowerCase();
    }
    function shouldHideForSpawn(command, options) {
      if (options?.windowsHide === false) {
        return false;
      }
      const base = getExecutableBaseName(command);
      if (BROWSER_EXECUTABLES.test(base)) {
        return false;
      }
      if (CONSOLE_EXECUTABLES.test(base)) {
        return true;
      }
      if (options?.shell) {
        return true;
      }
      if (/\.(cmd|bat)$/i.test(base)) {
        return true;
      }
      return false;
    }
    function withWindowsHideForExec2(options) {
      if (typeof options === "object" && options !== null && !Array.isArray(options)) {
        if (options.windowsHide === false) {
          return options;
        }
        return { ...options, windowsHide: true };
      }
      return { windowsHide: true };
    }
    function withWindowsHideForSpawn2(command, options) {
      const opts = typeof options === "object" && options !== null && !Array.isArray(options) ? { ...options } : {};
      if (!shouldHideForSpawn(command, opts)) {
        return opts;
      }
      return { ...opts, windowsHide: true };
    }
    module2.exports = {
      CONSOLE_EXECUTABLES,
      BROWSER_EXECUTABLES,
      getExecutableBaseName,
      shouldHideForSpawn,
      withWindowsHideForExec: withWindowsHideForExec2,
      withWindowsHideForSpawn: withWindowsHideForSpawn2
    };
  }
});

// src/core/winHideChildProcess.js
if (process.platform !== "win32") {
  return;
}
var cp = require("child_process");
var { withWindowsHideForExec, withWindowsHideForSpawn } = require_winHideChildProcessLogic();
function normalizeExecArgs(options, callback) {
  if (typeof options === "function") {
    return { options: withWindowsHideForExec({}), callback: options };
  }
  return { options: withWindowsHideForExec(options || {}), callback };
}
function normalizeSpawnArgs(command, args, options) {
  if (Array.isArray(args)) {
    return { args, options: withWindowsHideForSpawn(command, options || {}) };
  }
  return { args: [], options: withWindowsHideForSpawn(command, args || {}) };
}
var origExec = cp.exec.bind(cp);
cp.exec = function exec(cmd, options, callback) {
  const { options: opts, callback: cb } = normalizeExecArgs(options, callback);
  return origExec(cmd, opts, cb);
};
var origExecSync = cp.execSync.bind(cp);
cp.execSync = function execSync(cmd, options) {
  return origExecSync(cmd, withWindowsHideForExec(options || {}));
};
var origSpawn = cp.spawn.bind(cp);
cp.spawn = function spawn(command, args, options) {
  const normalized = normalizeSpawnArgs(command, args, options);
  return origSpawn(command, normalized.args, normalized.options);
};
var origSpawnSync = cp.spawnSync.bind(cp);
cp.spawnSync = function spawnSync(command, args, options) {
  const normalized = normalizeSpawnArgs(command, args, options);
  return origSpawnSync(command, normalized.args, normalized.options);
};
