"use strict";

// src/core/winHideChildProcessLogic.js
var path = require("path");
var CONSOLE_EXECUTABLES = /^(cmd|powershell|pwsh|wmic|tasklist|reg|findstr|where|whoami|systeminfo|netstat|sc|net|chcp|hostname|conhost)(\.exe)?$/i;
var BROWSER_EXECUTABLES = /^(sunbrowser|flowerbrowser|chrome|chromium|msedge|firefox|brave|opera)(\.exe)?$/i;
function getExecutableBaseName(command) {
  const trimmed = String(command).trim();
  let executable = trimmed;
  const quotedMatch = trimmed.match(/^"([^"]+)"|^'([^']+)'/);
  if (quotedMatch) {
    executable = quotedMatch[1] || quotedMatch[2];
  } else {
    executable = trimmed.split(/\s+/)[0] || trimmed;
  }
  executable = executable.replace(/^["']|["']$/g, "");
  return path.basename(executable.replace(/\\/g, "/")).toLowerCase();
}
function shouldHideForSpawn(command, options) {
  if (options?.windowsHide === false) {
    return false;
  }
  const base = getExecutableBaseName(command);
  if (BROWSER_EXECUTABLES.test(base)) {
    return false;
  }
  if (CONSOLE_EXECUTABLES.test(base)) {
    return true;
  }
  if (options?.shell) {
    return true;
  }
  if (/\.(cmd|bat)$/i.test(base)) {
    return true;
  }
  return false;
}
function withWindowsHideForExec(options) {
  if (typeof options === "object" && options !== null && !Array.isArray(options)) {
    if (options.windowsHide === false) {
      return options;
    }
    return { ...options, windowsHide: true };
  }
  return { windowsHide: true };
}
function withWindowsHideForSpawn(command, options) {
  const opts = typeof options === "object" && options !== null && !Array.isArray(options) ? { ...options } : {};
  if (!shouldHideForSpawn(command, opts)) {
    return opts;
  }
  return { ...opts, windowsHide: true };
}
module.exports = {
  CONSOLE_EXECUTABLES,
  BROWSER_EXECUTABLES,
  getExecutableBaseName,
  shouldHideForSpawn,
  withWindowsHideForExec,
  withWindowsHideForSpawn
};
